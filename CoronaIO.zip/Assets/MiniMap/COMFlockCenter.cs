﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class COMFlockCenter : MonoBehaviour
{
    public GameObject FlockCenter { get; set; }
}
